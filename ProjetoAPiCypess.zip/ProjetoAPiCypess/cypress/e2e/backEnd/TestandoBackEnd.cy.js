import { BackEndService } from "../../service/BackEnd/backEnd"

const backEnd = new BackEndService()


describe('Testando api Correio', () => {
it('testando api correio', () => {
    backEnd.TestandoApiCorreio();
})
});

