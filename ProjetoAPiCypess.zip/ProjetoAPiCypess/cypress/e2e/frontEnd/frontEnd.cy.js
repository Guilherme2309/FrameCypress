import { FrontEndService } from "../../service/FrontEnd/frontEnd";

const frontEnd = new FrontEndService();


describe('Testando Site Demo', () => {


it('Teste Advantage Onlaine Shop', () => {
    frontEnd.acessarSiteAdvantage();
    frontEnd.cliclarMenuCadastro();
})

});

