
export class BackEndService {

    TestandoApiCorreio() {
       
       
        cy.request(
            {
                method: 'GET',
                url : "https://example.api.findcep.com/v1/cep/01234000.json",
                headers: {
                    'Referer': 'example.com?_fid=E1NHRO71JEONCF'
                }
            }).as('response_Endereco').then((response) => {
                expect(response.status).to.eq(200)
                cy.get(response.body).each(($res) => {
                    cy.wrap($res.uf).should('not.be.empty')
                    cy.wrap($res.cidade).should('not.be.empty')
                    cy.wrap($res.bairro).should('not.be.empty')
                    cy.wrap($res.logradouro).should('not.be.empty')
                    cy.wrap($res.cep).should('not.be.empty')
                    cy.wrap($res.complemento).should('not.be.empty')
                    cy.wrap($res.status).should('not.be.empty')
                    cy.wrap($res.tipo).should('not.be.empty')
                    cy.wrap($res.codigo_ibge).should('not.be.empty')
                })
            })
    }

}