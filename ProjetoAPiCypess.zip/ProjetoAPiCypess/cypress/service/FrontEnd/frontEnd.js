const btnUser = '#menuUserLink'
const btnCriarNovaConta = '.create-new-account'
const cpUserName = ':nth-child(2) > [a-hint="Username"] > .inputContainer > .ng-pristine'
const cpEmail = '[sec-name="userEmail"] > .inputContainer > .ng-pristine'
const cpPassWord = ':nth-child(3) > [a-hint="Password"] > .inputContainer > .ng-pristine'
const cpConfPassword = '[a-hint="Confirm password"] > .inputContainer > label'
const cpNome = '[sec-name="userFirstName"] > .inputContainer > .ng-pristine'
const cpSobreNome = '[sec-name="userLastName"] > .inputContainer > .ng-pristine'
const cpTelefone = '[sec-name="registrationAgreement"] > .inputContainer > .ng-pristine'
const cpCidade = '[sec-name="userCity"] > .inputContainer > .ng-pristine'
const cpEndereco = '[sec-name="userAdress"] > .inputContainer'
const cpUf = '[sec-name="userState"] > .inputContainer > label'
const cpCep = '#formCover > :nth-child(3) > :nth-child(4) > .ng-isolate-scope > .inputContainer > .ng-pristine'
const btnCheckBox = '[sec-name="registrationAgreement"] > .inputContainer > .ng-valid'
const btnRegistrar = '#register_btnundefined'
const imgLogo = 'a > .roboto-medium'
const btnMinhaConta = '#loginMiniTitle > [translate="My_account"]'
const btnDeletarConta = '.deleteBtnText'
const btnYesDeletarConta = '.deleteRed'



export class FrontEndService {


    acessarSiteAdvantage() {

        cy.visit('https://www.advantageonlineshopping.com/#/');
    }

    cliclarMenuCadastro(){
        cy.get(btnUser).click();
        cy.get(btnCriarNovaConta).click();
        cy.get(cpUserName).type('fgoiiiste');
        cy.get(cpEmail).type('aiwuwuy@tlosse.com');
        cy.get(cpPassWord).type('Fc23097878');
        cy.get(cpConfPassword).type('Fc23097878');
        cy.get(cpNome).type('Guilherme');
        cy.get(cpSobreNome).type('Vargas');
        cy.get(cpTelefone).type('11949437192');
        cy.get(cpCidade).type('Sao paulo');
        cy.get(cpEndereco).type('av Gregorio Teste');
        cy.get(cpUf).type('Sp');
        cy.get(cpCep).type('04444000');
        cy.get(btnCheckBox).check();
        cy.get(btnRegistrar).click();
        cy.wait(5000);
        cy.get(imgLogo).should('be.visible');
        cy.wait(3000);
        cy.get(btnUser).click();
        cy.wait(3000);
        cy.get(btnMinhaConta).click();
        cy.wait(3000);
        cy.get(btnDeletarConta).click();
        cy.wait(3000);
        cy.get(btnYesDeletarConta).click();
       
    }
}