1;
2;
3;
4;
module.exports = {
  // The rest of the Cypress config options go here...
  projectId: "pn6gae",

  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
  },
};
